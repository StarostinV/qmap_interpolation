# Q map interpolation

Interpolation of diffraction images to reciprocal space

### Installation

Install via pip:

```shell script
pip install qmap_interpolation
```